//Kanyon Loyd
//ID = 1001537925
#include <iostream>
#include <vector>

using namespace std;

int main()
{

    vector<double> v1;
    vector<string> v2;
    string word;
    double num;
    int length;

    while(word!="STOP"){
        cout << "Enter a word or type STOP if finished: ";
        cin >> word;
        if(word!="STOP")
            v2.push_back(word);
    }

    while(num!=(-999.00)){
        cout << "Enter a double or type -999.00 if finished: ";
        cin >> num;
        if(num!=(-999.00))
            v1.push_back(num);
    }

    if(v1.size()>v2.size())
        length=v2.size();
    else
        length=v1.size();

    cout << endl;
    for(int i = 0; i<length; i++)
        cout << "String = " << v2[i] << "\t Double = " << v1[i] << endl;
}
