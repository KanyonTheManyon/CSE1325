//Kanyon Loyd
// ID = 1001537925

#include <iostream>
#include <fstream>
#include <sstream>
#include <cctype>
#include <vector>
#include <string>
#include <cstdlib>

using namespace std;

int main()
{
    string word;
    vector<string> v1;
    char ch;
    bool flag=true;
    double sum, num;
    int count = 0;

    ifstream myfile("sample.txt");
    ofstream output ("output.txt");
    if(myfile.is_open()){
        while(myfile >> word){
                v1.push_back(word);
        }

    for(int i=0; i<v1.size(); i++){
        flag = true;
        istringstream iss (v1[i]);
        while(iss >> ch){
                if(isalpha(ch)||isspace(ch))
                    flag=false;
        }
        if(flag){
            count++;
            num = stod(v1[i]);
            sum += num;
        }
        else{
            if(output.is_open())
            	output << v1[i] << endl;
            else
                cout << "Unable to write to file" << endl;
	}

    }
    cout << "Average of numbers: " << sum/count << endl;

    }
    else
        cout << "Unable to open file.";

    return 0;
}
