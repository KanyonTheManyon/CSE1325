//Sample Solution Provided by Dr. Gieser
#include "KWL7925_Allele.h"

char Allele::get_letter() const
{
	return letter;
}

bool Allele::get_dominance() const
{
	return dominance;
}
