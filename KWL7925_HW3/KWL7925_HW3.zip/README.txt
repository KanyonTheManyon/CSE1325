Make sure files are all in the same location and open the terminal at that location
then execute the makefile by typing the command "make all" in the terminal
Then type "./executable" to run the program
Follow the instructions in the program to add/change/view traits of the pea plant
Type 0 when finished in the program to terminate it.
Type make clean to remove the .o files
