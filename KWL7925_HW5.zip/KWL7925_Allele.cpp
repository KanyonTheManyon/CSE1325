//Sample Solution Provided by Dr. Gieser
#include "KWL7925_Allele.h"

Allele::Allele(char l, bool d) {
	letter = l;
	dominance = d;
}

char Allele::get_letter() const
{
	return letter;
}

bool Allele::get_dominance() const
{
	return dominance;
}
