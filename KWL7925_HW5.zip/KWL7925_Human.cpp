#include "KWL7925_Human.h"

Human::Human() {
	Allele a1 = { ' ', false };
	Genotype g1 = { a1, a1 };

	gender = { "Gender", g1, "" };
	rh_factor = { "Rh Factor", g1, "" };
	handedness = { "Handedness", g1, "" };
}

string Human::view_all_traits() {
	ostringstream oss;
	oss << endl << "Human Traits " << endl << gender << endl << rh_factor << endl << handedness << endl;
	return oss.str();
}

void Human::add_gender(Trait t) {
	gender = t;
}
void Human::add_rh_factor(Trait t) {
	rh_factor = t;
}
void Human::add_handedness(Trait t) {

	handedness = t;
}