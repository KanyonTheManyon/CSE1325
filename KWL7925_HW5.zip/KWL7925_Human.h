#ifndef KWL7925_HUMAN_H
#define KWL7925_HUMAN_H

#include "KWL7925_Living_Thing.h"
#include "KWL7925_Trait.h"


class Human : public Living_Thing {

public:
	Human();
	string view_all_traits();
	void add_gender(Trait t);
	void add_rh_factor(Trait t);
	void add_handedness(Trait t);
protected:
	Trait gender;
	Trait rh_factor;
	Trait handedness;

};


#endif //KWL7925_HUMAN_H
