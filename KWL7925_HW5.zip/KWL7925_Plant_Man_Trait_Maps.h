#ifndef KWL7925_PLANT_MAN_TRAIT_MAPS_H
#define KWL7925_PLANT_MAN_TRAIT_MAPS_H

#include "KWL7925_Pea_Plant_Trait_Maps.h"
#include "KWL7925_Human_Trait_Maps.h"
#include "KWL7925_Genotype.h"

class Plant_Man_Trait_Maps : public Pea_Plant_Trait_Map, public Human_Trait_Maps {

public: 
	Plant_Man_Trait_Maps();
};

#endif //KWL7925_PLANT_MAN_TRAIT_MAPS_H
