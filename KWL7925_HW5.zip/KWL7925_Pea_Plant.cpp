#include "KWL7925_Pea_Plant.h"

Pea_Plant::Pea_Plant()
{
	Allele a1 = { ' ', false };
	Genotype g1 = { a1, a1 };

	seed_color = { "Seed Color", g1, "" };
	pod_color = { "Pod Color", g1, "" };
	plant_height = { "Plant Height", g1, "" };
}

 string Pea_Plant::view_all_traits(){

	 ostringstream oss;
	 oss << endl << "Pea Plant Traits" << endl << seed_color << endl << pod_color << endl << plant_height << endl;
	 return oss.str();
 }

void Pea_Plant::add_seed_color(Trait t){
	seed_color = t;
}

void Pea_Plant::add_pod_color(Trait t){
	pod_color = t;
}

void Pea_Plant::add_plant_height(Trait t){
	plant_height = t;
}
