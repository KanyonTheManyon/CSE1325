#include "KWL7925_Plant_Man_Trait_Maps.h"
#include "KWL7925_Plant_Man.h"

Genotype trait_Maker(string trait, string type) {

	char letter;
	string dom;
	bool dominance;

	cout << "Please enter the 1st Allele for the " << trait << " trait for the " << type << " object: ";
	cin >> letter;
	cout << "Please enter the dominance of the 1st Allele of the " << trait << " trait for the " << type << " object(true/false): ";
	cin >> dom;
	if (dom == "true")
		dominance = true;
	else
		dominance = false;
	if ((isupper(letter) && dominance == false && trait != "Gender" && letter != 'Y') || (islower(letter) && dominance == true) || (letter == 'Y' && dominance == true && trait=="Gender"))
		throw mismatch_dom_letter();
	Allele a1(letter, dominance);
	cout << "Please enter the 2nd Allele for the " << trait << " trait for the " << type << " object: ";
	cin >> letter;
	cout << "Please enter the dominance of the 2nd Allele of the " << trait << " trait for the " << type << " object(true/false): ";
	cin >> dom;
	if (dom == "true")
		dominance = true;
	else
		dominance = false;
	if ((isupper(letter) && dominance == false && trait != "Gender" && letter != 'Y') || (islower(letter) && dominance == true) || (letter == 'Y' && dominance == true && trait=="Gender"))
		throw mismatch_dom_letter();
	Allele a2(letter, dominance);
	if (toupper(a1.get_letter()) != a2.get_letter() && tolower(a1.get_letter()) != a2.get_letter() && trait!="Gender")
		throw A_Error();
	Genotype g1(a1, a2);
	cout << endl;
	return g1;
}


int main()
{	
	bool loop = true;
	Human_Trait_Maps htm;
	Pea_Plant_Trait_Map pptm;
	Plant_Man_Trait_Maps pmtm;
	Human h1;
	Pea_Plant pp1;
	Plant_Man pm1;
	string gender = "Gender";
	string rh_factor = "Rh Factor";
	string handedness = "Handedness";
	string pod_color = "Pod Color";
	string seed_color = "Seed Color";
	string plant_height = "Plant Height";
	string human = "Human";
	string pea_plant = "Pea Plant";
	string plant_man = "Plant Man";

	while(loop)

	try {
		loop = false;
		Genotype g1 = trait_Maker(gender, human);
		string hgp = htm.get_gender_phenotype(g1);
		if (hgp == "")
			throw incorrect_letters();
 		Trait human_gen(gender, g1, hgp);
		h1.add_gender(human_gen);
		
		g1 = trait_Maker(rh_factor, human);
		string hrhp = htm.get_rh_factor_phenotype(g1);
		if(hrhp=="")
			throw incorrect_letters();
		Trait human_rh(rh_factor, g1, hrhp);
		h1.add_rh_factor(human_rh);

		g1 = trait_Maker(handedness, human);
		string hhand = htm.get_handedness(g1);
		if(hhand=="")
			throw incorrect_letters();
		Trait human_handedness(handedness, g1, hhand);
		h1.add_handedness(human_handedness);

		g1 = trait_Maker(pod_color, pea_plant);
		string pea_pc = pptm.get_pod_color_phenotype(g1);
		if(pea_pc=="")
			throw incorrect_letters();
		Trait pea_pod_color(pod_color, g1, pea_pc);
		pp1.add_pod_color(pea_pod_color);

		g1 = trait_Maker(seed_color, pea_plant);
		string pea_sc = pptm.get_seed_color_phenotype(g1);
		if(pea_sc=="")
			throw incorrect_letters();
		Trait pea_seed_color(seed_color, g1, pea_sc);
		pp1.add_seed_color(pea_seed_color);

		g1 = trait_Maker(plant_height, pea_plant);
		string pea_ph = pptm.get_plant_height_phenotype(g1);
		if (pea_ph == "")
			throw incorrect_letters();
		Trait pea_plant_height(plant_height, g1, pea_ph);
		pp1.add_plant_height(pea_plant_height);
		

		g1 = trait_Maker(gender, plant_man);
		string pmgp = pmtm.get_gender_phenotype(g1);
			if(pmgp=="")
				throw incorrect_letters();
		Trait pm_gen(gender, g1, pmgp);
		pm1.add_gender(pm_gen);

		g1 = trait_Maker(rh_factor, plant_man);
		string pmrhp = pmtm.get_rh_factor_phenotype(g1);
		if(pmrhp=="")
			throw incorrect_letters();
		Trait pm_rh(rh_factor, g1, pmrhp);
		pm1.add_rh_factor(pm_rh);

		g1 = trait_Maker(handedness, plant_man);
		string pmhand = pmtm.get_handedness(g1);
		if(pmhand=="")
			throw incorrect_letters();
		Trait pm_handedness(handedness, g1, pmhand);
		pm1.add_handedness(pm_handedness);

		g1 = trait_Maker(pod_color, plant_man);
		string pm_pc = pmtm.get_pod_color_phenotype(g1);
		if(pm_pc=="")
			throw incorrect_letters();
		Trait pm_pod_color(pod_color, g1, pm_pc);
		pm1.add_pod_color(pm_pod_color);

		g1 = trait_Maker(seed_color, plant_man);
		string pm_sc = pmtm.get_seed_color_phenotype(g1);
		if(pm_sc=="")
			throw incorrect_letters();
		Trait pm_seed_color(seed_color, g1, pm_sc);
		pm1.add_seed_color(pm_seed_color);

		g1 = trait_Maker(plant_height, plant_man);
		string pm_ph = pmtm.get_plant_height_phenotype(g1);
		if(pm_ph=="")
			throw incorrect_letters();
		Trait pm_plant_height(plant_height, g1, pm_ph);
		pm1.add_plant_height(pm_plant_height);
		

		cout << h1.view_all_traits() << endl << endl;
		cout << pp1.view_all_traits() << endl << endl;
		cout << pm1.view_all_traits() << endl << endl;
	
	}
	catch (mismatch_dom_letter& e) {
		cerr << "You did not correctly match the dominance with the letter " << endl;
		cerr << "Please try again! " << endl << endl;
		loop = true;
	}
	catch (A_Error a) {
		cerr << "You entered Alleles with two different letters. " << endl;
		cerr << "Please try again! " << endl << endl;
		loop = true;
	}
	catch (incorrect_letters& e) {
		cerr << "You entered incorrect letters for the trait" << endl;
		cerr << "Please try again! " << endl << endl;
		loop = true;
	}
	
	return 0;
	
}


