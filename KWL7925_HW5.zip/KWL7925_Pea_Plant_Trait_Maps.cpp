#include "KWL7925_Pea_Plant_Trait_Maps.h"

Pea_Plant_Trait_Map::Pea_Plant_Trait_Map()
{
	
	Allele sc1 = { 'Y', true };
	Allele sc2 = { 'y', false };
	Allele pc1 = { 'G', true };
	Allele pc2 = { 'g', false };
	Allele ph1 = { 'T', true };
	Allele ph2 = { 't', false };


	Genotype scg1 = { sc1, sc1 }; //Yellow
	Genotype scg2 = { sc1, sc2 }; //Yellow
	Genotype scg3 = { sc2, sc2 }; //Green
	Genotype pcg1 = { pc1, pc1 }; //Green
	Genotype pcg2 = { pc1, pc2 }; //Green
	Genotype pcg3 = { pc2, pc2 }; //Yellow
	Genotype phg1 = { ph1, ph1 }; //Tall
	Genotype phg2 = { ph1, ph2 }; //Tall
	Genotype phg3 = { ph2, ph2 }; //Short

	seed_color.insert(make_pair(scg1, "Yellow"));
	seed_color.insert(make_pair(scg2, "Yellow"));
	seed_color.insert(make_pair(scg3, "Green"));
	pod_color.insert(make_pair(pcg1, "Green"));
	pod_color.insert(make_pair(pcg2, "Green"));
	pod_color.insert(make_pair(pcg3, "Yellow"));
	plant_height.insert(make_pair(phg1, "Tall"));
	plant_height.insert(make_pair(phg2, "Tall"));
	plant_height.insert(make_pair(phg3, "Short"));

}



string Pea_Plant_Trait_Map::get_seed_color_phenotype(Genotype genotype){
	map<Genotype, string>::iterator it = seed_color.begin();
	for (; it != seed_color.end(); it++) {
		if (it->first.get_allele_one().get_letter() == genotype.get_allele_one().get_letter())
			if (it->first.get_allele_two().get_letter() == genotype.get_allele_two().get_letter())
				return it->second;
	}
	return "";
}


string Pea_Plant_Trait_Map::get_pod_color_phenotype(Genotype genotype){
	map<Genotype, string>::iterator it = pod_color.begin();
	for (; it != pod_color.end(); it++){
		if (it->first.get_allele_one().get_letter() == genotype.get_allele_one().get_letter())
			if (it->first.get_allele_two().get_letter() == genotype.get_allele_two().get_letter())
				return it->second;
	}
	return "";
}


string Pea_Plant_Trait_Map::get_plant_height_phenotype(Genotype genotype) {
	map<Genotype, string>::iterator it = plant_height.begin();
	for (; it != plant_height.end(); it++){
		if (it->first.get_allele_one().get_letter() == genotype.get_allele_one().get_letter())
			if (it->first.get_allele_two().get_letter() == genotype.get_allele_two().get_letter())
				return it->second;
	}
	return "";
}
