
#ifndef EXCEPTIONS_H
#define EXCEPTIONS_H

#include <exception>

class mismatch_dom_letter : public std::exception {};

class A_Error : public std::exception {};

class incorrect_letters : public std::exception {};

#endif //EXCEPTIONS_H
