#ifndef KWL7925_HUMAN_TRAIT_MAPS_H
#define KWL7925_HUMAN_TRAIT_MAPS_H

#include "KWL7925_Genotype.h"
#include <map>

class Human_Trait_Maps {
public:
	Human_Trait_Maps();
	string get_gender_phenotype(Genotype genotype);
	string get_rh_factor_phenotype(Genotype genotype);
	string get_handedness(Genotype genotype);
protected:
	map<Genotype, string> gender;
	map<Genotype, string> rh_factor;
	map<Genotype, string> handedness;
};


#endif //KWL7925_HUMAN_TRAIT_MAPS_H
