#ifndef KWL7925_PEA_PLANT_H
#define KWL7925_PEA_PLANT_H
#include "KWL7925_Trait.h"
#include "KWL7925_Living_Thing.h"


class Pea_Plant : public Living_Thing
{
    public:
        Pea_Plant();
        string view_all_traits();
        void add_seed_color(Trait t);
        void add_pod_color(Trait t);
        void add_plant_height(Trait t);

    protected:
        Trait seed_color;
        Trait pod_color;
        Trait plant_height;
};

#endif // KWL7925_PEA_PLANT_H
