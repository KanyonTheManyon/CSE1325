//Sample Solution Provided by Dr. Gieser
#include "KWL7925_Trait.h"

string Trait::get_name() const
{
	return name;
}

Genotype Trait::get_genotype() const
{
	return genotype;
}

string Trait::get_phenotype() const
{
	return phenotype;
}

ostream& operator<<(ostream& ost, const Trait& t)
{
	string output = "Name: " + t.name +"\nGenotype: " + string(1,t.get_genotype().get_allele_one().get_letter()) + string(1,t.get_genotype().get_allele_two().get_letter()) + "\nPhenotype: " + t.get_phenotype() + "\n";

	ost << output;

	return ost;
}
