#include "KWL7925_Living_Thing.h"
#include <sstream>

Living_Thing::Living_Thing(){}

string  Living_Thing::get_name() {
	return name;
}

