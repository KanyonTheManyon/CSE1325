#include "KWL7925_Plant_Man_Trait_Maps.h"

Plant_Man_Trait_Maps::Plant_Man_Trait_Maps() {}
