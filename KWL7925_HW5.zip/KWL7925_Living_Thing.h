#ifndef KWL7925_LIVING_THING_H
#define KWL7925_LIVING_THING_H
#include <string>
#include <sstream>

using namespace std;

class Living_Thing {

public:
	Living_Thing();
	Living_Thing(string n) : name(n) {};
	string get_name();
	virtual string view_all_traits() = 0;
protected:
	string name;
};

#endif //KWL7925_LIVING_THING_H
