#ifndef KWL7925_PLANT_MAN_H
#define KWL7925_PLANT_MAN_H

#include "KWL7925_Pea_Plant.h"
#include "KWL7925_Human.h"
#include "KWL7925_Trait.h"

class Plant_Man : public Pea_Plant, public Human {

public: 
	Plant_Man();
	string view_all_traits();
};

#endif //KWL7925_PLANT_MAN_H
