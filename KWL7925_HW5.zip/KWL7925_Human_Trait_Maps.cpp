#include "KWL7925_Human_Trait_Maps.h"

Human_Trait_Maps::Human_Trait_Maps()
{
	Allele g1 = { 'X', true };
	Allele g2 = { 'Y', false };
	Allele rh1 = { 'P', true };
	Allele rh2 = { 'p', false };
	Allele h1 = { 'R', true };
	Allele h2 = { 'r', false };


	Genotype gg1 = { g1, g1 }; //Female
	Genotype gg2 = { g1, g2 }; //Male
	Genotype rhg1 = { rh1, rh1 }; //Positive
	Genotype rhg2 = { rh1, rh2 }; //Positive
	Genotype rhg3 = { rh2, rh2 }; //Negative
	Genotype hg1 = { h1, h1 }; //Right
	Genotype hg2 = { h1, h2 }; //Right
	Genotype hg3 = { h2, h2 }; //Left

	gender.insert(make_pair(gg1, "Female"));
	gender.insert(make_pair(gg2, "Male"));
	rh_factor.insert(make_pair(rhg1, "Positive"));
	rh_factor.insert(make_pair(rhg2, "Positive"));
	rh_factor.insert(make_pair(rhg3, "Negative"));
	handedness.insert(make_pair(hg1, "Right"));
	handedness.insert(make_pair(hg2, "Right"));
	handedness.insert(make_pair(hg3, "Left"));

}



string Human_Trait_Maps::get_gender_phenotype(Genotype genotype) {
	map<Genotype, string>::iterator it = gender.begin();
	for (; it != gender.end(); it++) {
		if (it->first.get_allele_one().get_letter() == genotype.get_allele_one().get_letter())
			if (it->first.get_allele_two().get_letter() == genotype.get_allele_two().get_letter())
				return it->second;
	}
	return "";
}


string Human_Trait_Maps::get_rh_factor_phenotype(Genotype genotype) {
	map<Genotype, string>::iterator it = rh_factor.begin();
	for (; it != rh_factor.end(); it++) {
		if (it->first.get_allele_one().get_letter() == genotype.get_allele_one().get_letter())
			if (it->first.get_allele_two().get_letter() == genotype.get_allele_two().get_letter())
				return it->second;
	}
	return "";
}


string Human_Trait_Maps::get_handedness(Genotype genotype) {
	map<Genotype, string>::iterator it = handedness.begin();
	for (; it != handedness.end(); it++) {
		if (it->first.get_allele_one().get_letter() == genotype.get_allele_one().get_letter())
			if (it->first.get_allele_two().get_letter() == genotype.get_allele_two().get_letter())
				return it->second;
	}
	return "";
}