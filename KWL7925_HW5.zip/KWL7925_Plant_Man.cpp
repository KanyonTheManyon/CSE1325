#include "KWL7925_Plant_Man.h"

Plant_Man::Plant_Man() {
	Allele a1 = { ' ', false };
	Genotype g1 = { a1, a1 };

	seed_color = { "Seed Color", g1, "" };
	pod_color = { "Pod Color", g1, "" };
	plant_height = { "Plant Height", g1, "" };
	gender = { "Gender", g1, "" };
	rh_factor = { "Rh Factor", g1, "" };
	handedness = { "Handedness", g1, "" };
}

string Plant_Man::view_all_traits() {
	ostringstream oss;
	oss << endl << "Plant Man Traits " << endl << gender << endl << rh_factor << endl << handedness << endl;
	oss << seed_color << endl << pod_color << endl << plant_height << endl;
	return oss.str();
}