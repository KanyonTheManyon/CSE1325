//Sample Solution Provided by Dr. Gieser

#ifndef KWL7925_TRAIT_H
#define KWL7925_TRAIT_H
#include "KWL7925_Genotype.h"
#include <iostream>

class Trait
{
	public:
		Trait() {};
		Trait(string n, Genotype g, string p) : name(n), genotype(g), phenotype(p) {};
		string get_name() const;
		Genotype get_genotype() const;
		string get_phenotype() const;
		friend ostream& operator<<(ostream& ost, const Trait& t);
	private:
		string name;
		Genotype genotype;
		string phenotype;
};

#endif // KWL7925_TRAIT_H
