#ifndef ALLELE_H
#define ALLELE_H

#include <iostream>
using namespace std;

class Allele
{
    public:
        Allele(char l, bool d);
        char get_letter();
        bool get_dominance();
    private:
        char letter;
        bool dominance;
};

#endif
