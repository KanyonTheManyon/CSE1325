#include <iostream>
#include "KWL7925_Allele.h"
#include "KWL7925_Genotype.h"
#include "KWL7925_Trait.h"

using namespace std;

Allele::Allele(char l, bool d) : letter(l), dominance(d)
{
}

char Allele::get_letter()
{
    return letter;
}

bool Allele::get_dominance()
{
    return dominance;
}
