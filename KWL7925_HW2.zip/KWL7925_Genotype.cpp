#include <iostream>
#include "KWL7925_Allele.h"
#include "KWL7925_Genotype.h"
#include "KWL7925_Trait.h"

using namespace std;

Genotype::Genotype(Allele a_one, Allele a_two) : allele_one(a_one), allele_two(a_two)
{
}

Allele Genotype::get_allele_one()
{
    return allele_one;
}

Allele Genotype::get_allele_two()
{
    return allele_two;
}

bool Genotype::operator<(Genotype& rhs){
    if(allele_one.get_letter()<rhs.get_allele_one().get_letter())
        if(allele_two.get_letter()<rhs.get_allele_two().get_letter())
            return true;
    return false;
    }

