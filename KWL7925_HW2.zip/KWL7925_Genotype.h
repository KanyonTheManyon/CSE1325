#ifndef GENOTYPE_H
#define GENOTYPE_H
#include "KWL7925_Allele.h"

using namespace std;

class Genotype
{
    public:
        Genotype(Allele a_one, Allele a_two);
        Allele get_allele_one();
        Allele get_allele_two();
        bool operator<(Genotype& rhs);

    private:
        Allele allele_one;
        Allele allele_two;
};

#endif
