#include <iostream>
#include "KWL7925_Allele.h"
#include "KWL7925_Genotype.h"
#include "KWL7925_Trait.h"

using namespace std;

int main()
{
    Allele a1('R', true);
    Allele a2('r', false);
    Allele a3('Y', true);
    Allele a4('Y', true);
    Allele a5('i', false);
    Allele a6('i', false);
    Allele a7('G', true);
    Allele a8('g', false);
    Allele a9('P', true);
    Allele a10('P', true);
    Allele a11('A', true);
    Allele a12('a', false);
    Allele a13('t', false);
    Allele a14('t', false);

    Genotype g1(a1, a2);
    Genotype g2(a3, a4);
    Genotype g3(a5, a6);
    Genotype g4(a7, a8);
    Genotype g5(a9, a10);
    Genotype g6(a11, a12);
    Genotype g7(a13, a14);

    Trait t1("Seed Shape", g1, "Round");
    Trait t2("Seed Color", g2, "Yellow");
    Trait t3("Pod Shape", g3, "Constricted");
    Trait t4("Pod Color", g4, "Green");
    Trait t5("Flower Color", g5, "Purple");
    Trait t6("Flower Position", g6, "Axial");
    Trait t7("Plant Height", g7, "Short");

    cout << t1 << endl;
    cout << t2 << endl;
    cout << t3 << endl;
    cout << t4 << endl;
    cout << t5 << endl;
    cout << t6 << endl;
    cout << t7 << endl;
}
