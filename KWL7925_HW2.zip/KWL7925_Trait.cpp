#include <iostream>
#include "KWL7925_Allele.h"
#include "KWL7925_Genotype.h"
#include "KWL7925_Trait.h"
#include <string>

using namespace std;

Trait::Trait(string n, Genotype g, string p) : name(n), genotype(g), phenotype(p)
{}

string Trait::get_name()
{
    return name;
}

Genotype Trait::get_genotype()
{
    return genotype;
}

string Trait::get_phenotype()
{
    return phenotype;
}


ostream& operator<<(ostream& ost, Trait t){
        ost << "Name: " << t.get_name() << endl
        << "Genotype: " << t.get_genotype().get_allele_one().get_letter() << t.get_genotype().get_allele_two().get_letter() << endl
        << "Phenotype: " << t.get_phenotype() << endl;
        return ost;
}
