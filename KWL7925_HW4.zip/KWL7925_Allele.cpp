//Sample Solution Provided by Dr. Gieser
#include "KWL7925_Allele.h"

char Allele::get_letter() const
{
	return letter;
}

bool Allele::get_dominance() const
{
	return dominance;
}


ostream &operator<<(ostream &ost, const Allele &rhs){
	ost << "Using Allele Operator Overload " << endl;
	ost << "Letter: " << rhs.get_letter() << "\t Dominance:  " << rhs.get_dominance() << endl << endl;
	return ost;
}
