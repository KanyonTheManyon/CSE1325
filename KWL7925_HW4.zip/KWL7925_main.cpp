#include "KWL7925_Allele.h"
#include "KWL7925_Multiple_Allele.h"

int main() {

	Allele a('R', true);
	cout << "Allele Get Functions" << endl;
	cout << "Allele Letter: " << a.get_letter() << endl;
	cout << "Allele Dominance: " << a.get_dominance() << endl;
	cout << a;

	Multiple_Allele ma('G', false, 'g');
	cout << "Multiple Allele Get Functions" << endl;
	cout << "Multiple Allele Letter One: " << ma.get_letter() << endl;
	cout << "Multiple Allele Letter One Dominance: " << ma.get_dominance() << endl;
	cout << "Multiple Allele Letter Two: " << ma.get_letter_two() << endl;
	cout << ma;
	
	return 0;
}
