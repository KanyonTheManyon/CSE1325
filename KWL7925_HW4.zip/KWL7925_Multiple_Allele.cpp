#include "KWL7925_Multiple_Allele.h"

char Multiple_Allele::get_letter_two() const{
	return letter_two;
}

ostream &operator<<(ostream &ost, const Multiple_Allele &rhs) {
	ost << "Using Multiple Allele " << endl;
	ost << "Allele One: " << rhs.get_letter() << "\t Dominance:  " << rhs.get_dominance() << endl;
	ost << "Allele Two: " << rhs.get_letter_two() << endl;
	return ost;
}